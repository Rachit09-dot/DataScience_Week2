# Task 1: Basic Operations
# Accept two integer inputs
a = int(input("Enter first integer: "))
b = int(input("Enter second integer: "))

# Arithmetic operations
addition = a + b  #addition operation
subtraction = a - b  #subtraction operation
multiplication = a * b  #multiplication operation
division = a / b  #division operation
modulus = a % b  #modulus operation
exponent = a ** b  #exponentiation operation


# Display results
print("\n--- Arithmetic Results ---")
print(f"Addition: {addition}")
print(f"Subtraction: {subtraction}")
print(f"Multiplication: {multiplication}")
print(f"Division: {division}")
print(f"Modulus: {modulus}")
print(f"Exponentiation: {exponent}")